﻿using Hospital_Management_System.Models;
using System.Numerics;

namespace Hospital_Management_System
{
    public class Program
    {


        public static void RegisterPatient(HospitalContext context)
        {
            //----Patient Registration-----
            Console.WriteLine("Enter Patient Name:");
            string patientName = Console.ReadLine();

            Console.WriteLine("Enter Patient Age:");
            int patientAge = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Patient Email:");
            string patientEmail = Console.ReadLine();

            Console.WriteLine("Enter Patient Phone");
            string patientPhone = Console.ReadLine();

            Console.WriteLine("Enter Patient Gender");
            string patientGender = Console.ReadLine();

            Console.WriteLine("Enter PatientBloodType");
            string patientBloodType = Console.ReadLine();

            int patientId = (context.patients.Count) + 1; //calculated

            
            //add patient

            context.patients.Add(
                 new Patient
                 {
                     patientId = patientId,
                     patientName = patientName,
                     patientEmail = patientEmail,
                     patientPhone = patientPhone,
                     patientAge = patientAge,
                     patientBloodType = patientBloodType,
                     patientGender= patientBloodType

                 }

                );

            Console.WriteLine("Patient Added Successfully with ID " + patientId);
        }


        //----Add a New Doctor-----

        public static void AddDoctor(HospitalContext context)
        {
            Console.WriteLine("Enter doctor name:");
            string doctorName = Console.ReadLine();
            Console.WriteLine("Enter doctor specialization:");
            string doctorSpecialization = Console.ReadLine();

            Console.WriteLine("Enter doctor Email:");
            string doctorEmail = Console.ReadLine();

            Console.WriteLine("Enter doctor Phone");
            string doctorPhone = Console.ReadLine();

            Console.WriteLine("Enter consultationFee");
            int consultationFee = int.Parse(Console.ReadLine());

            int DoctorId = (context.doctors.Count) + 1;

            Doctor doctor = new Doctor
            {
                doctorId = DoctorId,
                doctorName = doctorName,
                doctorSpecialization = doctorSpecialization,
                doctorEmail = doctorEmail,
                doctorPhone = doctorPhone,
                consultationFee = consultationFee
            };

            context.doctors.Add(doctor);

            Console.WriteLine("Doctor Added Successfully");
            Console.WriteLine($"Assigned Doctor ID: {doctor.doctorId}");
        }



        //----View All Patients---

        public static void ViewAllPatients(HospitalContext context)
        {
            if (context.patients.Count == 0)
            {
                Console.WriteLine("No patients registered.");
                return;
            }

            foreach (Patient patient in context.patients)
            {
                Console.WriteLine($"ID: {patient.patientId}");
                Console.WriteLine($"Name: {patient.patientName}");
                Console.WriteLine($"Age: {patient.patientAge}");
                Console.WriteLine($"Gender: {patient.patientGender}");
                Console.WriteLine($"Phone: {patient.patientPhone}");
                Console.WriteLine($"Email: {patient.patientEmail}");
                Console.WriteLine($"blood:{patient.patientBloodType}");
            }
        }




        //----View All Doctors by Specialization----
        public static void ViewAllDoctorsBySpecialization(HospitalContext context)
        {
            Console.Write("Enter Specialization: ");
            string specialization = Console.ReadLine();

            bool found = false;

            foreach (Doctor doctor in context.doctors)
            {
                if (doctor.doctorSpecialization== specialization)
                {
                    found = true;

                    Console.WriteLine($"ID: {doctor.doctorId}");
                    Console.WriteLine($"Name: {doctor.doctorName}");
                    Console.WriteLine($"Specialization: {doctor.doctorSpecialization}");
                    Console.WriteLine($"Email: {doctor.doctorEmail}");
                    Console.WriteLine($"Phone: {doctor.doctorPhone}");
                    Console.WriteLine($"Consultation Fee: {doctor.consultationFee}");
                    
                }
            }

            if (!found)
            {
                Console.WriteLine("No doctors found with this specialization.");
            }
        }


        //----Add an Available Time Slot for a Doctor----

        
        public static void AddAvailableSlot(HospitalContext context)
        {
            Console.Write("Enter Doctor ID: ");
            int doctorId = int.Parse(Console.ReadLine());

            bool found = false;

            foreach (Doctor d in context.doctors)
            {
                if (d.doctorId == doctorId)
                {
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine("Doctor not found.");
                return;
            }

            Console.Write("Enter Date: ");
            string slotDate = Console.ReadLine();

            Console.Write("Enter Time: ");
            string slotTime = Console.ReadLine();

            int slotId = context.availableSlots.Count + 1;

            AvailableSlot slot = new AvailableSlot
            {
                slotId = slotId,
                doctorId = doctorId,
                slotDate = slotDate,
                slotTime = slotTime,
                isBooked = false
            };

            context.availableSlots.Add(slot);

            Console.WriteLine("Available slot added successfully.");
        }




        static void Main(string[] args)
            {
                //data storage for the system ( in memory )
                HospitalContext context = new HospitalContext();
                {
                    patients = new List<Patient>();
                    doctors = new List<Doctor>();
                    appointments = new List<Appointment>();
                    medicalRecords = new List<MedicalRecord>();
                    availableSlots = new List<AvailableSlot>();
                };









            }
        }
    }