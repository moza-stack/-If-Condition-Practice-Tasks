﻿using Hospital_Management_System.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System
{
    //system storage
    public class HospitalContext
        {
            public List<Patient> patients{ get; set; }
            public List<Doctor> doctors { get; set; }
            public List<Appointment> appointments { get; set; }
            public List<MedicalRecord> medicalRecords { get; set; }
            public List<AvailableSlot> availableSlots { get; set; }
        }
    }

//public class HospitalContext
//{
//    public List<Patient> patients = new List<Patient>();
//    public List<Doctor> doctors = new List<Doctor>();
//    public List<Appointment> appointments = new List<Appointment>();
//    public List<MedicalRecord> medicalRecords = new List<MedicalRecord>();
//    public List<AvailableSlot> availableSlots = new List<AvailableSlot>();
//}

